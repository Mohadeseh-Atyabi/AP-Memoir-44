package com.company;

/**
 * It is the two team in the game.
 */
public enum Team {
    AXIS,
    ALLIED
}
